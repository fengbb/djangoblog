.. _release-notes:

Release notes
=============

The |version| release of |project| now supports Python 2.x, 3.x and
Django 1.4, 1.5, 1.6, and 1.7.
