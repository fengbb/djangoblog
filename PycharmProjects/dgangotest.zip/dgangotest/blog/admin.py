from django.contrib import admin
from blog.models import User, Author, Blog, Category, Comments

# Register your models here.
from . import models

#admin.site.register(models.Article)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'username', 'realname', 'sex', 'email')
    search_fields = ('username',)
    list_filter = ('username',)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('authorname', 'email')
    search_fields = ('authorname',)
    list_filter = ('authorname',)
class BlogAdmin(admin.ModelAdmin):
    list_display = ('title', 'classify', 'summary',  'authors', 'createdate', 'keyword', 'img', 'thumb')
    search_fields = ('title',)
    list_filter = ('createdate',)
    date_hierarchy = 'createdate'
    ordering = ('-createdate',)
    fields = ('title', 'classify', 'summary', 'authors', 'img', 'keyword', 'thumb', 'content', 'createdate' )
admin.site.register(User, UserAdmin)
admin.site.register(Author, AuthorAdmin)
admin.site.register(Blog, BlogAdmin)
admin.site.register(Category)
admin.site.register(Comments)