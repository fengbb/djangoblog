# Create your views here.

#def year_archive(request, year):
#    a_list = Article.objects.filter(pub_date__year=year)
#    context = {'year': year, 'article_list': a_list}
#    return render(request, '../templates/year_archive.html', context)
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.core.files.storage import default_storage

from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models.fields.files import FieldFile
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.contrib import messages
from .forms import ContactForm, FilesForm, ContactFormSet
from models import Blog
from django.http import HttpResponse, Http404
from django.template import loader, Context
from blog import cutstr
from django.shortcuts import render_to_response
from django.core.mail import send_mail
from django.http import HttpResponseRedirect


# http://yuji.wordpress.com/2013/01/30/django-form-field-in-initial-data-requires-a-fieldfile-instance/
class FakeField(object):
    storage = default_storage


fieldfile = FieldFile(None, FakeField, 'dummy.txt')


#class HomePageView(TemplateView):
#    template_name = 'home.html'
def contact(request):
    errors = []
    if request.method == 'POST':
        if not request.POST.get('subject', ''):
            errors.append('Enter a subject.')
        if not request.POST.get('message', ''):
            errors.append('Enter a message.')
        if request.POST.get('email') and '@' not in request.POST['email']:
            errors.append('Enter a valid e-mail address')
        if not errors:
            send_mail(
                request.POST['subject'],
                request.POST['message'],
                request.POST.get('email', '122727569@qq.com'),
                ['15353531182@163.com'],
            )
            return HttpResponseRedirect('thanks')
    return render_to_response('contact_form.html', {
         'errors': errors,
         'subject': request.POST.get('subject', ''),
         'message': request.POST.get('message', ''),
         'email': request.POST.get('email', ''),
         })
def home(request):
        #context = super(HomePageView, self).get_context_data(**kwargs)
        #messages.info(self.request, 'This is a demo of a message.')
        blogs = Blog.objects.all()
        #nblogs = Blog.objects.all().values("createdate")
        nblogs = Blog.objects.all()[0:5]
        hblogs = Blog.objects.order_by("-hits")[0:5]
        #hblogs1 = Blog.objects.order_by("hits")[0:1]
        #hblogs2 = Blog.objects.order_by("hits")[1:2]
        #hblogs3 = Blog.objects.order_by("hits")[2:3]
        #hblogs4 = Blog.objects.order_by("hits")[3:4]
        #hblogs5 = Blog.objects.order_by("hits")[4:5]
        t = loader.get_template("home.html")
        #c = Context({'blogs': blogs, 'nblogs': nblogs, 'hblogs': hblogs, 'hblogs1': hblogs1, 'hblogs2': hblogs2, 'hblogs3': hblogs3, 'hblogs4': hblogs4, 'hblogs5': hblogs5})
        c = Context({'blogs': blogs, 'nblogs': nblogs, 'hblogs': hblogs})
        return HttpResponse(t.render(c))
def base(request):
    hblogs = Blog.objects.order_by("hits")[0:5]
    t = loader.get_template("base.html")
    c = Context({'hblogs': hblogs})
    return HttpResponse(t.render(c))
def blogdisplay(request, bid):
    try:
        bid = int(bid)
    except ValueError:
        raise Http404
    blogs = Blog.objects.all()
    #nblogs = Blog.objects.all().values("createdate")
    nblogs = Blog.objects.all()[0:5]
    hblogs = Blog.objects.order_by("-hits")[0:5]
    blogInfo = Blog.objects.get(id=bid)
    blogdisp = blogInfo.content
    blogtitle = blogInfo.title
    blogcreatedate = blogInfo.createdate
    blogauthor = blogInfo.authors
    blogreads = blogInfo.readnumber
    bloghits = blogInfo.hits
    blogInfo.readnumber += 1
    blogInfo.hits += 1
    blogInfo.save()
    dt = loader.get_template("display1.html")
    dc = Context({'blogdisp': blogdisp, 'blogtitle': blogtitle, 'blogcreatedate': blogcreatedate, 'blogauthor': blogauthor, 'blogreads': blogreads, 'bloghits': bloghits, 'nblogs': nblogs, 'hblogs': hblogs})
    return HttpResponse(dt.render(dc))
def dsiplay_meta(request):
    values = request.META.items()
    values.sort()
    html = []
    for k, v  in values:
        html.append('<tr><td>%s</td><td>%s</td></tr>' % (k, v))
        return HttpResponse('<table>%s</table>' % '\n'.join(html))
#def search_form(request):
#    return render_to_response('search_form.html')
def search(request):
    errors = []
    if 'q' in request.GET:
        q = request.GET['q']
        if not q:
            errors.append('Enter a search term.')
        elif len(q) > 20:
            errors.append('Please enter at most 20 characters.')
        else:
            blogs = Blog.objects.filter(title__icontains=q)
            return render_to_response('search_results.html',
                {'blogs': blogs, 'query': q})
    return render_to_response('search_form.html',{'errors': errors})
       #return HttpResponse('Please submit a search term.')

def entirety(request):
        #context = super(HomePageView, self).get_context_data(**kwargs)
        #messages.info(self.request, 'This is a demo of a message.')
        blogs = Blog.objects.all()
        t = loader.get_template("entirety.html")
        c = Context({'blogs': blogs})
        return HttpResponse(t.render(c),'bid')

class DefaultFormsetView(FormView):
    template_name = 'formset.html'
    form_class = ContactFormSet


class DefaultFormView(FormView):
    template_name = 'form.html'
    form_class = ContactForm


class DefaultFormByFieldView(FormView):
    template_name = 'form_by_field.html'
    form_class = ContactForm


class FormHorizontalView(FormView):
    template_name = 'form_horizontal.html'
    form_class = ContactForm


class FormInlineView(FormView):
    template_name = 'form_inline.html'
    form_class = ContactForm


class FormWithFilesView(FormView):
    template_name = 'form_with_files.html'
    form_class = FilesForm

    def get_context_data(self, **kwargs):
        context = super(FormWithFilesView, self).get_context_data(**kwargs)
        context['layout'] = self.request.GET.get('layout', 'vertical')
        return context

    def get_initial(self):
        return {
            'file4': fieldfile,
        }

class PaginationView(TemplateView):
    template_name = 'pagination.html'

    def get_context_data(self, **kwargs):
        context = super(PaginationView, self).get_context_data(**kwargs)
        lines = []
        for i in range(10000):
            lines.append('Line %s' % (i + 1))
        paginator = Paginator(lines, 10)
        page = self.request.GET.get('page')
        try:
            show_lines = paginator.page(page)
        except PageNotAnInteger:
            # If page is not an integer, deliver first page.
            show_lines = paginator.page(1)
        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results.
            show_lines = paginator.page(paginator.num_pages)
        context['lines'] = show_lines
        return context


class MiscView(TemplateView):
    template_name = 'misc.html'

